import sys
import numpy as np,pandas as pd,pyarrow.parquet as pq
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import cg
from scipy.stats import norm
acc='Boston College|Clemson|Duke|Florida St.|Georgia Tech|Louisville|Miami (FL)|North Carolina|NC State|Notre Dame|Pittsburgh|Syracuse|Virginia|Virginia Tech|Wake Forest'.split('|')
def run(y):
 teams=acc+(['California','SMU','Stanford'] if y>=2025 else [])
 slots=[f'{side}_{i}' for side in ['home','away'] for i in range(1,6)]
 d=pq.read_table(f'hist/{y}.parquet',columns=slots+['home','away','poss_team','pts','contest_id','game_date']).to_pandas()
 ids=[];lookup={};labels=[]
 for i,col in enumerate(slots):
  side='home' if i<5 else 'away'
  codes,unique=pd.factorize(pd.MultiIndex.from_arrays([d[side],d[col].fillna('')]))
  mapped=[]
  for team,name in unique:
   if not name or name in ('UNKNOWN','TEAM') or 'UNKNOWN' in name: mapped.append(-1);continue
   key=(team,name)
   if key not in lookup:lookup[key]=len(labels);labels.append(key)
   mapped.append(lookup[key])
  ids.append(np.array(mapped)[codes])
 line=np.column_stack(ids);valid=(line.min(1)>=0)&(np.diff(np.sort(line,axis=1),axis=1)!=0).all(1)&d.pts.between(0,5)&((d.poss_team==d.home)|(d.poss_team==d.away))
 for scope in ['all']:
  mask=valid.copy()
  if scope=='ACC':mask &= d.home.isin(teams)&d.away.isin(teams)&(pd.to_datetime(d.game_date,format='mixed').dt.month.isin([12,1,2,3]))
  a=line[mask]; home=(d.poss_team[mask]==d.home[mask]).to_numpy()
  pts=d.pts[mask].to_numpy(float);target=(pts-np.where(home,pts[home].mean(),pts[~home].mean()))*np.where(home,200,-200)
  n=len(labels);X=csr_matrix((np.tile([1.]*5+[-1.]*5,len(a)),a.ravel(),np.arange(0,a.size+1,10)),shape=(len(a),n))
  offense=np.where(home[:,None],a[:,:5],a[:,5:])
  defense=np.where(home[:,None],a[:,5:],a[:,:5])
  X=csr_matrix((X.data,np.column_stack([offense,defense+n]).ravel(),X.indptr),shape=(len(a),2*n))
  gram=X.T@X;gram.setdiag(gram.diagonal()+1000)
  v,info=cg(gram,X.T@(target*np.where(home,.5,-.5)),rtol=1e-7);assert info==0
  out=pd.DataFrame(labels,columns=['school','name']);out['O']=v[:n];out['D']=v[n:];out['volume']=np.log1p(np.bincount(a.ravel(),minlength=n))
  strength=out.assign(weight=(out.O+out.D)*np.expm1(out.volume),exposure=np.expm1(out.volume)).groupby('school')[['weight','exposure']].sum()
  out['team_strength']=out.school.map(strength.weight/strength.exposure)
  out.to_csv(f'hist/split{y}.csv',index=False)
if __name__=='__main__':run(int(sys.argv[1]))
