"""Rebuild lineups and observed offensive trips from the supplied ESPN JSON."""
import collections as C
import gzip, glob, json, os, sys
import pandas as pd
from itertools import groupby

SIDES=('home','away')
ACTORS={'shot','assist','turnover','steal','block','rebound','freeThrow','jumpBall'}
def analyze(meta,d):
    roster={p['key']:p for p in d['players']}
    minutes=C.Counter()
    scores=C.Counter()
    trips=[]
    reasons=set()
    def reject(key): reasons.add(key)
    plays=sorted(d['plays'],key=lambda e:e['seq'])
    for period,iterator in groupby(plays,lambda e:e['period']):
        events=list(iterator)
        length=d['periodSeconds'] if period<=d['regulationPeriods'] else d['overtimeSeconds']
        first={s:{} for s in SIDES}
        for e in events:
            side,key=e.get('side'),e.get('playerKey')
            if side not in SIDES or key not in roster: continue
            if e['kind']=='substitution': first[side].setdefault(key,e.get('substitution')=='out')
            elif e['kind'] in ACTORS: first[side].setdefault(key,True)
        active={}
        for s in SIDES:
            active[s]=set(d['starters'].get(s,[])) if period==1 else {k for k,on in first[s].items() if on}
            if len(active[s])!=5: reject('period_starters')
        previous=length
        current=None
        for e in events:
            clock=e.get('clock')
            if clock is None: clock=0 if e['kind']=='periodEnd' else previous
            delta=previous-clock
            if delta<0 or clock<0 or clock>length: reject('clock')
            if delta>0:
                for s in SIDES:
                    if len(active[s])!=5: reject('five_on_floor')
                    for k in active[s]: minutes[k]+=delta
            previous=clock
            k,s,kind=e.get('playerKey'),e.get('side'),e['kind']
            if s not in SIDES: continue
            if kind=='substitution':
                if e.get('substitution')=='out':
                    if k not in active[s]: reject('sub_conflict')
                    active[s].discard(k)
                elif e.get('substitution')=='in':
                    if k in active[s]: reject('sub_conflict')
                    active[s].add(k)
                else: reject('sub_direction')
                continue
            if kind in ACTORS and k in roster and k not in active[s]: reject('actor_off_floor')
            if kind not in ('shot','freeThrow','turnover'): continue
            if any(len(active[t])!=5 for t in SIDES): reject('five_on_floor')
            points=int(e.get('value',0)) if e.get('made') else 0
            scores[s]+=points
            lineup=(tuple(sorted(active[s])),tuple(sorted(active[SIDES[1-SIDES.index(s)]])))
            if current is None or current['side']!=s:
                current={'side':s,'line':lineup,'points':0,'stable':True}
                trips.append(current)
            current['points']+=points
            current['stable'] &= current['line']==lineup
        if previous>0:
            for s in SIDES:
                if len(active[s])!=5: reject('five_on_floor')
                for k in active[s]: minutes[k]+=previous
    if (scores['home'],scores['away'])!=(meta['hs'],meta['aws']): reject('score')
    errors=[abs(minutes[k]-p['boxSeconds']) for k,p in roster.items() if p.get('boxSeconds') is not None]
    if not errors or any(p.get('boxSeconds') is None for k,p in roster.items() if minutes[k]>0): reject('box_missing')
    if errors and max(errors)>120: reject('minutes')
    used={k for t in trips for side in t['line'] for k in side}
    if any(k not in roster or not roster[k].get('playerId') for k in used): reject('player_id')
    if len({roster[k].get('playerId') for k in used if k in roster})!=len(used): reject('identity_collision')
    out=[]
    if not reasons:
        for t in trips:
            if not t['stable']: continue
            off,deff=t['line']
            out.append([meta['game'],meta['date'],t['side'],t['points'],meta['ht'],meta['at'],*[roster[k]['playerId'] for k in off+deff]])
    return out,dict(game=meta['game'],date=meta['date'],trips=len(trips),retained=len(out),max_seconds_error=max(errors,default=None),flags='|'.join(sorted(reasons))),[(p['playerId'],p['name'],meta['ht'] if p['side']=='home' else meta['at']) for p in roster.values() if p.get('playerId')]
def main(root='work',out='deliver'):
    games={g['game']:g for g in json.load(open(root+'/games.json'))}
    seen=set(); audits=[]; rows=[]; names=[]
    for path in glob.glob(root+'/raw/*.gz'):
        for item in json.load(gzip.open(path)):
            game=item['game']
            if game in seen: continue
            seen.add(game)
            try: data,audit,players=analyze(games[game],item['data'])
            except (KeyError,TypeError,ValueError) as e:
                audits.append(dict(game=game,date=games[game]['date'],flags='parse_'+type(e).__name__,retained=0));continue
            rows.extend(data);audits.append(audit);names.extend(players)
    assert seen==set(games), (len(seen),len(games))
    pd.DataFrame(audits).to_csv(out+'/game_audit.csv',index=False)
    pd.DataFrame(rows,columns=['game','date','side','points','home','away']+['o'+str(i) for i in range(5)]+['d'+str(i) for i in range(5)]).to_pickle(root+'/trips.pkl')
    pd.DataFrame(names,columns=['id','name','team']).value_counts().rename('games').reset_index().sort_values('games',ascending=False).drop_duplicates('id').to_csv(root+'/names.csv',index=False)
if __name__=='__main__':main()
