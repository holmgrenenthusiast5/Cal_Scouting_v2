import numpy as np,pandas as pd
v=pd.read_csv('cal_fit/backtest.csv')
b=pd.read_csv('cal_fit/scenarios.csv');err=(v.actual-v.context).to_numpy();p=b['Forecast at California'];b['80% RAPM low']=p+np.quantile(err,.1);b['80% RAPM high']=p+np.quantile(err,.9)
for col,threshold in [('Chance above ACC median (%)','benchmark_median'),('Chance top quarter (%)','benchmark_top')]:
 b[col]=[100*np.mean(mu+err>t) if pd.notna(mu) else np.nan for mu,t in zip(p,b[threshold])]
cols=['Player','2025–26 school','Current school','Current class','O_pre','D_pre','Total RAPM','Forecast at California','80% RAPM low','80% RAPM high','Chance above ACC median (%)','Chance top quarter (%)']
b[cols].rename(columns={'O_pre':'Measured ORAPM','D_pre':'Measured DRAPM'}).sort_values('Forecast at California',ascending=False).to_csv('cal_fit/Cal_board.csv',index=False,float_format='%.2f')
print(b[cols].iloc[0].to_string());print(v.groupby('year_post').apply(lambda g:pd.Series({k:g[k].corr(g.actual) for k in ['context','common_destination','prior']})))
