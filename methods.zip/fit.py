"""Fit one-season RAPM on verified offensive trips; evaluate chronological game splits."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import cg

def design(offense, defense, home):
    labels=np.unique(np.concatenate((offense.ravel(),defense.ravel())))
    total=len(home); n=len(labels)
    cols=np.column_stack([np.searchsorted(labels,offense),n+np.searchsorted(labels,defense),np.full(total,2*n),np.full(total,2*n+1)])
    data=np.column_stack([np.ones(offense.shape),-np.ones(defense.shape),np.ones(total),home])
    matrix=coo_matrix((data.ravel(),(np.repeat(np.arange(total),cols.shape[1]),cols.ravel())),shape=(total,2*n+2)).tocsr()
    return matrix,labels

def solve(x,y,penalty):
    gram=(x.T@x).tocsr()
    diagonal=np.full(gram.shape[0],float(penalty));diagonal[-2:]=0
    gram=gram+diags(diagonal)
    coefs,info=cg(gram,x.T@y,M=diags(1/gram.diagonal()),atol=1e-7,rtol=1e-9,maxiter=1500)
    if info:raise RuntimeError(f'Unconverged fit: {info}')
    return coefs

def measure(rows,pred):
    grouped=rows[['game','side','points']].copy()
    grouped['actual']=100*grouped.points
    grouped['prediction']=pred
    pairs=grouped.groupby(['game','side'])[['actual','prediction']].mean().unstack('side')
    margin=pairs.xs('home',axis=1,level=1)-pairs.xs('away',axis=1,level=1)
    err=margin.prediction-margin.actual
    return dict(games=len(err),trips=len(pred),margin_mae=abs(err).mean(),margin_rmse=np.sqrt((err**2).mean()),trip_rmse=np.sqrt(np.mean((grouped.actual-pred)**2)),winner_rate=((margin.prediction>0)==(margin.actual>0))[margin.actual!=0].mean())

def run(root='work',out='deliver'):
    source=Path(root)/'trips.pkl'
    t=pd.read_pickle(source) if source.exists() else pd.read_csv(Path(root)/'trips.csv.gz')
    t=t.sort_values(['date','game']).reset_index(drop=True)
    date=t.date.str[:10]
    days=t[['game','date']].drop_duplicates().sort_values('date').date.str[:10]
    val_start=days.iloc[int(len(days)*.65)];test_start=days.iloc[int(len(days)*.8)]
    train=(date<val_start).to_numpy();val=((date>=val_start)&(date<test_start)).to_numpy();test=(date>=test_start).to_numpy()
    home=(t.side=='home').to_numpy(); y=100*t.points.to_numpy()
    op=t[['o'+str(i) for i in range(5)]].to_numpy();dp=t[['d'+str(i) for i in range(5)]].to_numpy()
    xp,ids=design(op,dp,home)
    ot=np.where(home,t.home,t.away)[:,None];dt=np.where(home,t.away,t.home)[:,None];xt,_=design(ot,dt,home)
    scores=[];chosen={}; final=None
    for model,x in [('home_only',xp[:,-2:]),('team',xt),('player',xp)]:
        candidates=[0] if model=='home_only' else [25,100,400,1000,2500]
        for a in candidates:
            c=solve(x[train],y[train],a)
            scores.append(dict(model=model,split='validation',penalty=a,**measure(t[val],x[val]@c)))
        best=min((r for r in scores if r['model']==model and r['split']=='validation'),key=lambda r:r['margin_rmse'])['penalty']
        chosen[model]=best
        c=solve(x[~test],y[~test],best)
        scores.append(dict(model=model,split='test',penalty=best,**measure(t[test],x[test]@c)))
        if model=='player': final=solve(x,y,best)
    pd.DataFrame(scores).to_csv(out+'/validation.csv',index=False)
    n=len(ids); a=np.bincount(np.searchsorted(ids,op).ravel(),minlength=n); b=np.bincount(np.searchsorted(ids,dp).ravel(),minlength=n)
    exposure=pd.DataFrame({'id':np.concatenate([op.ravel(),dp.ravel()]),'game':np.tile(np.repeat(t.game.values,5),2)})
    games=exposure.drop_duplicates().groupby('id').size()
    board=pd.DataFrame(dict(id=ids,off_rapm=final[:n],def_rapm=final[n:2*n],off_trips=a,def_trips=b))
    board['net_rapm']=board.off_rapm+board.def_rapm
    board['verified_games']=board.id.map(games)
    board['meets_trip_minimum']=(a>=500)&(b>=500)
    names=pd.read_csv(root+'/names.csv')
    teams=pd.read_json(root+'/teams.json').set_index('id')
    names['school']=names.team.map(teams['name'])
    board=board.merge(names[['id','name','team','school']],on='id',how='left').sort_values('net_rapm',ascending=False)
    for divisor,label in [(2,'lighter'),(.5,'stronger')]:
        alternative=solve(xp,y,chosen['player']/divisor)
        values=pd.Series(alternative[:n]+alternative[n:2*n],index=ids)
        qualified=board.loc[board.meets_trip_minimum,'id']
        ranks=values.loc[qualified].rank(ascending=False,method='min').astype(int)
        board['rank_'+label+'_penalty']=board.id.map(ranks).astype('Int64')
    board.to_csv(out+'/all_player_estimates.csv',index=False,float_format='%.4f')
    board=board[board.meets_trip_minimum].copy()
    board.insert(0,'rank',np.arange(1,len(board)+1))
    board.to_csv(out+'/scouting_board.csv',index=False,float_format='%.4f')
    meta=dict(validation_from=val_start,test_from=test_start,chosen_penalties=chosen,n_players=n,n_board=len(board),n_trips=len(t),n_games=t.game.nunique(),earliest=date.min(),latest=date.max())
    Path(out+'/fit_summary.json').write_text(json.dumps(meta,indent=2))
    print(meta);print(pd.DataFrame(scores).query("split=='test'").to_string(index=False));print(board[['rank','name','school','net_rapm','off_rapm','def_rapm','verified_games']].head(12).to_string(index=False))
if __name__=='__main__':run()
