import gzip,json,re,unicodedata
import numpy as np,pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from pathlib import Path
def key(s):return re.sub('(junior|jr|iii|ii|iv)$','',re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s.lower()).encode('ascii','ignore').decode()))
stats=[];strength=[]
for y in range(2019,2027):
 d=pd.DataFrame(json.load(gzip.open(f'hist/adv{y}.gz')))
 print(y,'score check',(2*d[23]+3*d[25]+d[27]==d[33]).mean(),flush=True)
 sums=d.groupby(51)[[8,23,24,25,26,27,28,33]].sum()
 fga=sums[24]+sums[26]
 stats.append(pd.DataFrame({'id':sums.index,'efg':(sums[23]+1.5*sums[25])/(fga+1),'three_rate':sums[26]/(fga+1),'ft_rate':sums[28]/(fga+1),'shots40':40*fga/(1+sums[8]),'year_pre':y}))
 s=pd.read_csv(f'hist/split{y}.csv');strength.append(s.groupby('school').team_strength.first().rename('dest').reset_index().assign(year_pre=y))
stats=pd.concat(stats);strength=pd.concat(strength)
d=pd.read_csv('transfer_audit/observed_moves.csv').merge(stats,on=['id','year_pre'],how='left').merge(strength,left_on=['school_post','year_pre'],right_on=['school','year_pre'],how='left').dropna(subset=['O_pre','D_pre','O_post','D_post']);d['actual']=d.O_post+d.D_post;d['prior']=d.O_pre+d.D_pre
acc=pd.read_csv('transfer_audit/ACC_moves.csv');d=d.merge(acc[['year_post','id']].assign(isacc=True),how='left');d['isacc']=d.isacc.eq(True)
basic=['O_pre','D_pre'];extra=basic+['boxO_pre','boxD_pre','usage_pre','volume_pre','team_strength_pre','efg','three_rate','ft_rate','shots40','dest']
def model(t,cols):return make_pipeline(SimpleImputer(),StandardScaler(),Ridge(alpha=15)).fit(t[cols],t.actual)
fold=[]
for y in range(2022,2027):
 t=d[d.year_post<y];a=t[t.isacc];v=d[(d.year_post==y)&d.isacc].copy()
 v['old']=model(a,basic).predict(v[basic]);v['context']=model(t,extra).predict(v[extra]);v['common_destination']=model(t,extra).predict(v.assign(dest=t.dest.median())[extra]);v['acc_only']=model(a,extra).predict(v[extra]); fold.append(v)
v=pd.concat(fold);v.to_csv('cal_fit/backtest.csv',index=False)
for label,g in [('all',v),('recent',v[v.year_post>=2024]),('latest',v[v.year_post==2026]),('elite',v[v.prior>=7])]:
 print(label,len(g),'actual',g.actual.mean(),[(k,round(g[k].corr(g.actual),3),round((g[k]-g.actual).abs().mean(),2),round(g[k].mean(),2)) for k in ['old','context','common_destination','acc_only','prior']])
b=pd.read_csv('raw_model/Board.csv');s=pd.read_csv('hist/split2026.csv');s['key']=s.name.map(key);box=pd.read_csv('hist/box2026.csv');box['key']=box.player.map(key);b['key']=b.Player.map(key)
b=b.merge(s[~s.key.duplicated(False)][['key','volume','team_strength']],how='left').merge(box[~box.key.duplicated(False)],on='key',how='left').merge(stats[stats.year_pre==2026],on='id',how='left')
b=b.rename(columns={'Measured ORAPM':'O_pre','Measured DRAPM':'D_pre','boxO':'boxO_pre','boxD':'boxD_pre','usage':'usage_pre','team_strength':'team_strength_pre','volume':'volume_pre'})
for dest in ['California','Louisville']:
 b['dest']=strength.query('year_pre==2026 and school==@dest').dest.iloc[0];ok=b.O_pre.notna()
 b.loc[ok,'Forecast at '+dest]=model(d,extra).predict(b.loc[ok,extra])
print(b.head(1)[['Player','Forecast at California','Forecast at Louisville']])
b.to_csv('cal_fit/scenarios.csv',index=False)
